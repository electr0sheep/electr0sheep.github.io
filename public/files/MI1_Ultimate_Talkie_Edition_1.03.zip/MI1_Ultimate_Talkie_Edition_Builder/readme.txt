The Secret of Monkey Island - Ultimate Talkie Edition Project            V1.03
=============================================================
The official home of this inofficial patch can be found here:
www.gratissaugen.de/ultimatetalkies

Content:
1.  Requirements
2.  Installing
2.1 Installing it for ScummVM
2.2 Installing it for DOS
3.  Playing
3.1 Playing it with ScummVM
3.2 Playing it in DOS
3.3 Preferences
4.  What this release is all about
4.1 Summary
  WARNING: Sections 4.2 - 6. contain lots of spoilers. Don't read them, if you didn't play the game yet!
4.2 Bugs fixed
4.3 Talky-friendly script adaptions
4.4 Misc enhancements
4.5 New boot params
4.6 Debug keys
5.  Known problems
6.  Future plans
7.  License and credits

1.  Requirements
================
- The Secret of Monkey Island - Special Edition PC version installed.
- xWMAEncode.exe from Microsoft's DirectX sdk.
- Approximately 1 GB temporary disk space, 194 MB for DOS, 825 MB for FLAC and 168 MB for Ogg Vorbis version.
- Windows XP or later.
- And finally, any device able to run SCUMM V5 games.
- The DOS version requires VGA (unlike the original game).


2.  Installing
==============

2.1 Installing it for ScummVM
=============================
- Remove any previous version of this patch from your game folder.
- Extract MI1_Ultimate_Talkie_Edition_1.02.zip and put the MI1_Ultimate_Talkie_Edition_Builder folder where you have Monkey1.pak installed.
- Get a copy of xWMAEncode.exe and put it inside the tools subfolder. (The file is not included for legal reasons.)
- Run install_flac.bat for highest quality audio and wait for the MI1 Ultimate Talkie Edition to be created.
- Alternatively run install_ogg.bat to get a smaller, but data reduced monkey.sog instead of monkey.sof. This might be preferable on devices with small storage capacity.
- Optionally, if you prefer having the SE's extended environment tracks in the main game folder, so they will play in every music mode, run extended_SE_tracks_to_game_folder.bat
- Now add the game as usual, plus the extra path of the music version of your choice.
- Your original files won't be altered.

2.2 Installing it for DOS
=========================
- Remove any previous version of this patch from your game folder.
- Extract MI1_Ultimate_Talkie_Edition_1.02.zip and put the MI1_Ultimate_Talkie_Edition_Builder folder where you have Monkey1.pak installed.
- Get a copy of xWMAEncode.exe and put it inside the tools subfolder. (The file is not included for legal reasons.)
- Run install.bat and wait for the MI1 Ultimate Talkie Edition to be created.
- Your original files won't be altered.


3.  Playing
===========

3.1 Playing it with ScummVM
===========================
- Just start the game as usual.
- Hint: If you prefer MIDI mode without any additional soundtrack, you can get rid of the ripping reminder by just putting a silent dummy track1 into the game folder.

3.2 Playing it in DOS
=====================
- Run "monkey r1" for playing with Roland MT-32 music.
- Run "monkey r" for playing with General MIDI music.
- Run "monkey a" for playing with AdLib music.
- The game can be played either from a harddisk or directly off CD.
- Hit '[' and ']' to adjust the music volume.

3.3 Preferences
===============
- CTRL-a toggles narrator mode.
- CTRL-p toggles Spiffy mode between "SE based VGA", "EGA scan" and "no closeup".
- CTRL-q toggles subtitle mode between "keep original text" and "match voice acting".
- CTRL-t toggles speech/subtitle mode
- Preferences are stored in monkey.cfg, which is loaded automatically whenever a new game is started.
- Music volume is saved whenever one of those toggles are used.
- Savegames contain their own settings overiding monkey.cfg when loaded, except for music volume.


4.  What this release is all about
==================================

4.1 Summary
===========
- It builds a talkie version for DOS and ScummVM out of the Special Edition.
- No dead ends.
- Higher quality and some additional sound effects from the SE.
- Music support for MT-32, brand new General MIDI and AdLib. Including Stan's theme and the extended LeChuck theme.
- ScummVM support for both, the old CD audio tracks and the SE tracks.
- Spiffy close-up
- Plenty of original bugs fixed.

******************************************************************************
WARNING: From here on, this document contains lots of spoilers. If you didn't play the game yet, don't read further!

4.2 Bugs fixed
==============
This list includes original bugs as well as bugs in this patch from previous releases.

v0.5 beta:
- The storekeeper closes the door AFTER he walks to the counter. (all versions except EGA)
- "The basic theory is fine." of the Fettucini Brothers is now peoperly animated and subtitled. (all versions)
- Smirk's cigar's smoke positioning. (all versions)
- Smirk's cigar has no smoke in the close up. (enhanced CD)
- Guybrush occasionally refuses to burn the cereals, even after the journey to Monkey Island and vice versa.
- Animal notice with bad background color. (enhanced CD)
- Wrong colors due to palette changes (enhanced CD): Talk colors for the navigator, Estevan (glass eye in SCUMM bar), Bob and the ghost priest (which had even 3 different colors), sentence line when dead and during the auto sequence in the Governor's mansion, Dialog selection in the upside down text at the circus, in the close-up for the navigator and the final close-up with Elaine and Guybrush, and finally Guybrush skin and hair when he's dying.
- The "Still ten o'clock"-joke messed up. (enhanced CD)
- "Jam. Rum." appears in the wrong location. (enhanced CD)
- The "Order hint book" joke. (enhanced CD) They probably removed that feature when they discontinued that service, but who would order a hint book nowadays anyway? So enjoy the joke.
- Stump joke. (Amiga, enhanced CD) And yes, it is a joke. Don't bother asking LucasArts for disc 22! They removed that joke because of people doing so all the time in the first place.
- "use" the helmet at the circus didn't work. (enhanced CD)

v0.6 beta:
- Python not required anymore. (v0.5 beta)
- Extract_classic.exe could crash. (v0.5 beta)
- Piranha poodles pausing before eating the meat. (all versions)
- Navigator malfunctions. (native enhanced CD, all versions on ScummVM as of v1.1.1)
- Ghost key cloning. (all versions)
- Storekeeper walks through mid-air when shortening the first open safe cutscene early. (all versions)
- "Use pewter wad with ???" can cause an error if it disappears from inventory, but the command isn't executed yet, ie. Guybrush is still walking to the target object. (all versions)
- Men of Low Moral Fiber missing text, timing, giggling, hitting and subtitling improved. (v0.5 beta)
- Cast spelling. (original SE errors)
- Firework sounds working in the DOS version. Not during conversation, though, which is a limitation of native SCUMM V5. (v0.5 beta)
- On the Sea Monkey, dripping water animation speed. (enhanced CD)
- Use cereals while they are still in the cupboard with something causes a fatal error in the DOS version. (enhanced CD)
- Clueless rubber chicken comment, even after figuring out what it's good for. (all versions)

v0.7 beta:
- Converting CD audio and SE music tracks. (v0.6 beta)
- "Thanks" at Stan with wrong voice. (v0.5 beta)
- Picking up yellow flower not animated. (all versions)
- Yellow petal is green at Stan's. Among other color glitches. (enhanced CD)
- Random swordfighting pirates have all the same colors (enhanced CD)
- Blue floor color in the kitchen door from the Scumm bar, despite the kitchen has a brown floor. (enhanced CD).
- Beat the swordmaster cheat re-implemented. Cheats are only available in debug mode.
- Safe sound not playing for every move. (ScummVM problem with the SE sound)
- Added sounds for Scumm Bar chef crying, LeChuck punching Guybrush and Stan, grog machine crash and shaking, monkeys eating bananas, monkey head key and monkey bride.
- Added ambient tracks for Melee Town and Monkey Island river.
- Added accentuation differences of right and wrong insult's replies.
- Debug keys on unfeasible combinations. (DOSbox defaults, ScummVM and even native SCUMM V5)
- Open exit door in the Scumm bar cuts off the table. (all VGA versions)

v0.8 beta:
- The narrator is now available on CTRL-a.
- Talk color for the voodoo lady. (enhanced CD)
- The codewheel query now works as intended. (v0.5 beta)
- Mancomb's missing chair and blue scum. (all VGA versions)
- Cyan pixels in spinning Scumm Bar pirates. (all VGA versions)
- missing sign on the ghost ship deck. (all versions except EGA)
- Various costume regressions. (enhanced CD)
- Shaking animation of grog machine. (enhanced CD)
- LeChuck removing his sheriff costume has a cyan beard for a brief moment. (all VGA versions)
- downward flying LeChuck has flashing hands. (all VGA versions)
- line with missing voice at the Loom guy. (v0.5 beta)
- Lookout dialog. (v0.5 beta)
- Firework colors and lightning effect. (all VGA versions)
- Too bright costume palette in some rooms. (enhanced CD)
- Torch colors in jail. (enhanced CD)
- Lamp in mansion light color. (enhanced CD)
- Colored corner at the sign on the banana tree. (enhanced CD)
- Jolly Roger still visible on the mast after cooking. (all versions)
- Added additional notices for restored jokes to prevent misunderstandings.

v0.9 beta:
- Ultimate Talkie Edition Project credits added.
- Adlib Soundtrack added.
- FLAC and Ogg Vorbis support for highest quality in ScummVM.
- Removed the panning when talking to Spiffy in closeup modes, since it doesn't serve a purpose here.
- Ram leak when interrupting playing sounds. (v0.6 beta)
- "<ADVERTISEMENT>" broken when stump joke or death joke was presented first. (v0.8 beta)
- Using alt-w causes a script error during the intro sequence. (v0.8 beta)
- Scumm Bar does not scroll after going through all Spiffy dialog. (v0.5 beta)
- Voodoo antiroot crate requires the tools when opening it again. (all versions)
- Voodoo antiroot crate comment "I don't see anything special about it. Except that big glowing voodoo antiroot inside.", even if Guybrush already grabbed it. (all versions)
- Improved cauldron colors in the voodoo shop. (all VGA versions)
- Storekeeper's comment on Guybrush pretending to wait tables. (all versions).
- Estevan's eye colors. Now it looks like a glas eye again. (enhanced CD)
- Estevan's fear eye animation. (all VGA versions)
- Candles at Stan's not animated. (all versions)
- Candles in the Scumm Bar kitchen are now animated as they were in the demo.
- More sound tweaking: Jail doors and chests included. And it should run fine in DOS now.
- Some more ambient tracks.
- Punch sound added to Men of Low Moral Fiber.

v1.0 RC1:
- "Raff." with a Guybrush sample when the dog is talking. (v0.5 beta)
- Low volume in DOS. Now it starts with the same default volume the original game had. In addition to that, your adjusted volume can be saved to monkey.cfg. (v0.5 beta)
- Subtitle mode toggle added.
- Title sequence now uses iMuse for beat matching instead of inaccurate timers. (v0.5 beta)
- Dialog option "You say you got a key from the locals?" did appear only if Guybrush did NOT learn about the key. Now it is the other way around. (all versions)
- Dialog option "You're the only one on the island?" was availabe instead of "So you're not the only one on the island?" under some circumstances, even when he just told about the key he got from the locals. (all versions)
- Stan did say "Inflation works in the other direction, you know." when you offer the same amount twice, even if your previous offer was less. (all versions)
- Stan had no voice for many possible values. This is now fixed for anything up to 10950 pieces of eight. (Special Edition)
- The porthole defogger now is actually worth something. (all versions)

v1.0 RC2:
- Environment sounds mixed into Scumm Bar music.
- No Charles Atlas, but Guybrush now says: "He's pretty creepy." (a voiced line) which makes more sense than "No thanks.  I'd rather not touch any of this creepy voodoo stuff." when you just look at it. (enhanced CD)
- Swordmaster invisible after showing the kidnapper's note. (v0.5 beta)
- Wrong colors with some boot params. (v1.0 RC1)
- Walking off path after visiting Sword Master's (enhanced CD)

v1.0 RC3:
- New games had always subtitles turned on in ScummVM. (v0.5 beta)
- Animation was out of sync in first LeChuck cutscene. (v0.5 beta)
- Scumm Bar music not always stopping in MIDI mode. (v0.9 beta)
- Verbs flashing between rooms in hell maze. (enhanced CD)
- CD audio detection improved. (v0.9 beta)

v1.0 RC4:
- More goofs in the Herman dialog fixed.

v1.0 RC7 (not public):
- Slight delay before "All I got was a feather." in the DOS version.
- Dying LeChuck sound problem in the DOS version.
- Batch file to give you the choice of moving the extended environmental tracks into main game folder.

v1.0:
- Fixed some remaining typos.
- Readme reflects recent ScummVM updates.
- Legal stuff.

v1.01:
- Sampled sound problems during talking when playing the DOS-Version with General MIDI or Roland MT-32 in some rooms.

v1.02:
- Disappearing line on the notice at the mansion. This only appeared in the DOS version in "text and voice" mode.
- Fixed another Herman dialog good.

v1.03:
- Added scummpacker.exe to tools
- Added xWMAEncode.exe to tools
- Fixed some typos in script echos
- Added ctrl+t to readme

4.3 Talky-friendly script adaptions
===================================
- Seperated all insults and replies to those characters which can potentially use them.
- Seperated "That's no helmet." to individual characters.
- Replaced several timed message with regular waitForMessage in order to make sure, they won't get cut off early. Except for a few scenes, where they are ment to get interrupted. For instance, the initial dialog option at the circus.
- Several sounds are played by special scripts to make sure they don't interrupt talking characters.
- Threepwood variants limited to those which actually have a voice file.
- "I have ### pieces of eight." limited to those which actually have a voice file. Otherwise use the "I have enough money for anything I need to buy." and "I have enough money for anything I need to buy, except a ship.". The latter is used when the 3 trials are solved AND you didn't got the ship yet.
- Guybrush offers Stan: "Oh^ no more than a hundred odd pieces of eight." if he has an amount which has no voice file.
- "You could sail this puppy away TODAY, for just \xFF\x04\xC6\x00 pieces of eight." is used when the value is higher than 10950. Unfortunately, there seems no universal voice file available for this. The SE uses just a wrong number whenever no voice file is available. I think, just keep that line without voice is less irritating than that.
- Disabled flashing of "Har Har Har" and "GROG!!!" texts, since it doesn't work correctly with voice files.
- Disabled advancing "Pssst." and similar moving subtitles effect. (Except subtitled noises which were already present in the original game, ie. meant to accompany them.)
- Looking at the Governor's poster waits for camera before the text starts.
- Unlike the pirate leader instances, "Rum. Jam" and "Jam. Rum." are separated samples, which had to be mixed together.
- The "The Machine" voice sample had to be mixed with the sound effect, since SCUMM V5 has no sample polyphony. (You won't hear the sound anymore, if you turn of voice acting.)
- Several enhancements to the Men with Low Moral Fiber.
- Some samples are changed in its volume to better fit the flow. For instance, the "Pssst." was far too loud and is reduced by 15 dB.
- Workaround for hardcoded Indy4 boot param, so that restart works properly.

4.4 Misc enhancements
=====================
- Wasting money into the grog machine works only once. Trying again, and Guybrush says: "I'm not stupid enough to do that twice.". Push and Pull don't activate the machine, unless a coin was inserted, so it goes conform with the "open" action. And "look at" is the default action, now.
- Also wasting money to Otis is patched to work only once. He just replies "I don't need your charity buddy." on further attempts.
- I added a retry verb at the death scene. Hard to believe, but I heard of people really spending more then 10 minutes to figure out what to do here. The button appears after clicking on "order hint book".
- Voice cast and "Ultimate Talkie Edition Project" credits added.

4.5 New boot params
===================
- 1: Starts the code wheel query. Debug mode not required.
- 116: All insults known.
- 117: At Stan's with pot, fish, meat, yellow petal and 2 pieces of eight.
- 335: At dock close-up with fireworks.
- Add 10000 to any boot param to force the game into MIDI mode.

4.6 Debug keys
==============
I changed some debug keys to ScummVM and DOSbox friendly combinations. Some of the original keys weren't even available in native SCUMM due to changes between V4 and V5.

In the DOS version, type hardyharhar and then press CTRL-d (there is no confirmation message).
In ScummVM, simply add the -d parameter to the command line.

Keys available in DOS and ScummVM (scripted):
f6        add 100 pieces of eight cheat. (during conversation mode)
f7        buy ship cheat at Stans. With exclusive voice acting! (during conversation mode)
f9        beat the swordmaster cheat. (during walk mode)
a         cycle through actor control.
7/8       cylce through talk subtitle colors.
f2/f3     cycle through costume color index
q/e       cycle through palette colors for selected costume color index.
CTRL-o    print color palette
r         face left/right
f         face front
b         face back
h         costume light level 75%
j         costume light level 88%
k         costume light level 100%
f4        toggle machine speed. Disables some animations for slow machines.

Keys available in the DOS version only (hardcoded):
CTRL-d    disable debug mode
CTRL-f    fast mode (ScummVM has this too). Also on ALT as a momentary button.
CTRL-g    load room.
CTRL-k    display RAM availability.
CTRL-l    restart with boot param.


5.  Known problems
==================
- Some official ScummVM versions quit with "SO_LOAD_STRING: Unsupported filename monkey.cfg". Upgrade to the latest version should fix this.
- Savegames made with other versions won't work.
- The DOS version does not support CD audio. (Not even with the resource files copied to the hard disk).
- When lying on the kitchen's floor on the Sea Monkey, there is no voice acting for "Fsspt.", "Grrfk.", "Psspert.", "Aaak.", "Blfftp.". They weren't voiced in the SE either.
- "You could sail this puppy away TODAY, for just ##### pieces of eight." has no voice for any amount above 10950 pieces of eight.
- There are no voice files for the following Swordmaster lines "I've got a long, sharp lesson for you to learn today.", "I said:".
- The infamous stump joke isn't voiced either, because it doesn't exists in the SE.
- Those missing lines are avoided when subtitle mode is set to "match voice acting" (default), but you'll miss on some jokes then.
- The '.'-key does not work correctly in ScummVM with Stan's spliced lines.
- Command line boot params don't work in the DOS version. This is due to hard coded boot params meant to bypass Indy4's manual query when the game is restarted.


6.  Future plans
================
- Fixing Meathooks eyepatch switching sides.


7.  License and credits
=======================
This patch is freeware and distributed with no warranty. You may use it at your own risk. Non-commercial use only. You may re-distribute the patch, but not the resulting game.

3rd party tools usage:
- Sound eXchange is released under the GNU General Public License version 2 and available at http://sox.sourceforge.net/
- scummpacker by jestar_jokin released as public domain available at http://www.jestarjokin.net/
- fatecd.exe and dottcd.exe are patches available at http://www.lucasarts.com/support/updates.html.
- 7zip is released under GNU LGPL and available at http://www.7-zip.org/
- bsdiff is released under the BSD Protection License and available at http://www.daemonology.net/bsdiff/
- extract_classic is a simplified version of extractpak
- unxwb is released under the GNU General Public License version 2 and available at http://aluigi.org
- xWMAEncode by Microsoft is part of the direct x sdk, available at http://www.microsoft.com (The file is not included for legal reasons.)

misc credits:
- Altered graphics implemented by Simon Sawatzki.
- Stan's theme is based on a MIDI by Mr. Coulomb
- Extended LeChuck theme is based on a MIDI by Highland Productions
- EGA scan Spiffy close-up implemented by cocomonk22